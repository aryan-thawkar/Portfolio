#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <chrono>

using namespace std;
using namespace chrono;

// Merge function for Merge Sort
void merge(vector<int>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;
    
    vector<int> leftArr(n1), rightArr(n2);
    
    for (int i = 0; i < n1; i++)
        leftArr[i] = arr[left + i];
    for (int i = 0; i < n2; i++)
        rightArr[i] = arr[mid + 1 + i];
    
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (leftArr[i] <= rightArr[j]) {
            arr[k] = leftArr[i];
            i++;
        } else {
            arr[k] = rightArr[j];
            j++;
        }
        k++;
    }
    
    while (i < n1) {
        arr[k] = leftArr[i];
        i++;
        k++;
    }
    while (j < n2) {
        arr[k] = rightArr[j];
        j++;
        k++;
    }
}

// Merge Sort function
void mergeSort(vector<int>& arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

int main() {
    // Read numbers from file
    ifstream inFile("random_numbers.txt");
    if (!inFile) {
        cerr << "Error opening random_numbers.txt!" << endl;
        return 1;
    }
    
    vector<int> numbers;
    int num;
    while (inFile >> num) {
        numbers.push_back(num);
    }
    inFile.close();
    
    // Measure sorting time
    auto start = high_resolution_clock::now();
    mergeSort(numbers, 0, numbers.size() - 1);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop - start);
    
    // Save sorted numbers
    ofstream sortedFile("sorted_numbers.txt");
    if (!sortedFile) {
        cerr << "Error opening sorted_numbers.txt!" << endl;
        return 1;
    }
    for (int num : numbers) {
        sortedFile << num << endl;
    }
    sortedFile.close();
    
    cout << "Merge Sort completed in " << duration.count() << " milliseconds." << endl;
    cout << "Sorted numbers saved in sorted_numbers.txt" << endl;
    
    return 0;
}