#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#define vi vector<int>
#define vvi vector<vi>
#define rep(i, a, b) for (int i = a; i < b; i++)

void DFS(int node, vector<vector<int>>& adjm, vector<bool>& visited) {
    visited[node] = true;
    cout << node << " ";

    for (int i = 0; i < adjm.size(); i++) { 
        if (adjm[node][i] == 1 && !visited[i]) { 
            DFS(i, adjm, visited);
        }
    }
}

void DFT(vector<vector<int>>& adjm) {
    int startNode;
    cout << "Enter the starting node for DFS (0 to " << adjm.size() - 1 << "): ";
    cin >> startNode;

    if (startNode < 0 || startNode >= adjm.size()) {
        cout << "Invalid starting node!" << endl;
        return;
    }

    vector<bool> visited(adjm.size(), false);
    cout << "DFS Traversal: ";
    DFS(startNode, adjm, visited);
    cout << endl;
}

void BFT(vector<vector<int>>& adjm) {
    int startNode;
    cout << "Enter the starting node for BFS (0 to " << adjm.size() - 1 << "): ";
    cin >> startNode;

    if (startNode < 0 || startNode >= adjm.size()) {
        cout << "Invalid starting node!" << endl;
        return;
    }

    vector<bool> visited(adjm.size(), false);
    queue<int> q;
    visited[startNode] = true;
    q.push(startNode);

    cout << "BFS Traversal: ";
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        cout << node << " ";

        for (int i = 0; i < adjm.size(); i++) {
            if (adjm[node][i] == 1 && !visited[i]) {
                visited[i] = true;
                q.push(i);
            }
        }
    }
    cout << endl;
}

int main() {
    int n, m, graphType;
    cout << "Enter number of Nodes and Edges: ";
    cin >> n >> m;

    vvi adjm(n, vi(n, 0));  

    cout << "Enter Graph Type (1: Directed, 0: Undirected): ";
    cin >> graphType;

    if (graphType != 0 && graphType != 1) {
        cout << "Invalid entry!" << endl;
        return 0;
    }

    cout << "Enter Edges (Node1 Node2):" << endl;
    rep(i, 0, m) {
        int x, y;
        cin >> x >> y;
        adjm[x][y] = 1;
        if (graphType == 0) {
            adjm[y][x] = 1;
        }
    }

    cout << "\nAdjacency Matrix:\n";
    rep(i, 0, n) {
        rep(j, 0, n) {
            cout << adjm[i][j] << " ";
        }
        cout << endl;
    }

    cout << "\nChoose traversal method:\n1. Depth First Traversal (DFS)\n2. Breadth First Traversal (BFS)\n";
    int choice;
    cin >> choice;

    if (choice == 1) {
        DFT(adjm);
    } else if (choice == 2) {
        BFT(adjm);
    } else {
        cout << "Invalid choice!" << endl;
    }

    return 0;
}
