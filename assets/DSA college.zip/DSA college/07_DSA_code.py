def dijkstra(graph, source):
    n = len(graph)
    visited = [False] * n
    distance = [float('inf')] * n
    distance[source] = 0

    for _ in range(n):
        min_dist = float('inf')
        min_node = -1
        for i in range(n):
            if not visited[i] and distance[i] < min_dist:
                min_dist = distance[i]
                min_node = i

        if min_node == -1:
            break

        visited[min_node] = True

        for neighbor in range(n):
            if graph[min_node][neighbor] != 0 and not visited[neighbor]:
                new_dist = distance[min_node] + graph[min_node][neighbor]
                if new_dist < distance[neighbor]:
                    distance[neighbor] = new_dist

    print(f"\nShortest distances from node {source}:")
    for i in range(n):
        if distance[i] == float('inf'):
            print(f"Node {i}: Unreachable")
        else:
            print(f"Node {i}: {distance[i]}")

graph = [
    [0, 4, 0, 0, 0, 0, 0, 8, 0],
    [4, 0, 8, 0, 0, 0, 0, 11, 0],
    [0, 8, 0, 7, 0, 4, 0, 0, 2],
    [0, 0, 7, 0, 9, 14, 0, 0, 0],
    [0, 0, 0, 9, 0, 10, 0, 0, 0],
    [0, 0, 4, 14, 10, 0, 2, 0, 0],
    [0, 0, 0, 0, 0, 2, 0, 1, 6],
    [8, 11, 0, 0, 0, 0, 1, 0, 7],
    [0, 0, 2, 0, 0, 0, 6, 7, 0]
]

def main():
    print("Graph has 9 nodes (0 to 8)")
    source = int(input("Enter the source node: "))
    dijkstra(graph, source)

if __name__ == "__main__":
    main()
