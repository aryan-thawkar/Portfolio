#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>

using namespace std;
using namespace chrono;

// Partition function for QuickSort
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    
    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

// QuickSort function
void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main() {
    // Read numbers from file
    ifstream inFile("random_numbers.txt");
    if (!inFile) {
        cerr << "Error opening random_numbers.txt!" << endl;
        return 1;
    }
    
    vector<int> numbers;
    int num;
    while (inFile >> num) {
        numbers.push_back(num);
    }
    inFile.close();
    
    // Measure sorting time
    auto start = high_resolution_clock::now();
    quickSort(numbers, 0, numbers.size() - 1);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop - start);
    
    // Save sorted numbers
    ofstream sortedFile("sorted_numbers.txt");
    if (!sortedFile) {
        cerr << "Error opening sorted_numbers.txt!" << endl;
        return 1;
    }
    for (int num : numbers) {
        sortedFile << num << endl;
    }
    sortedFile.close();
    
    cout << "QuickSort completed in " << duration.count() << " milliseconds." << endl;
    cout << "Sorted numbers saved in sorted_numbers.txt" << endl;
    
    return 0;
}
