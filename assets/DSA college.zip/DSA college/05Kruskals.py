class DisjointSet:
    def __init__(self, vertices):
        self.parent = {v: v for v in vertices}
        self.rank = {v: 0 for v in vertices}

    def find(self, v):
        if self.parent[v] != v:
            self.parent[v] = self.find(self.parent[v])
        return self.parent[v]

    def union(self, u, v):
        root1 = self.find(u)
        root2 = self.find(v)

        if root1 != root2:
            if self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            elif self.rank[root1] < self.rank[root2]:
                self.parent[root1] = root2
            else:
                self.parent[root2] = root1
                self.rank[root1] += 1

def kruskal_algorithm(vertices, edges):
    mst = []
    total_weight = 0

    edges.sort(key=lambda edge: edge[2])
    ds = DisjointSet(vertices)

    for u, v, weight in edges:
        if ds.find(u) != ds.find(v):
            ds.union(u, v)
            mst.append((u, v, weight))
            total_weight += weight

    return mst, total_weight

vertices = ['P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'A1', 'B1', 'C1']
edges = [
    # Graph1
    ('P', 'Q', 2), ('Q', 'R', 5), ('P', 'S', 3), ('R', 'S', 4), ('P', 'R', 6),

    # Graph2
    ('T', 'U', 7), ('U', 'V', 3), ('T', 'V', 8),

    # Graph3
    ('W', 'X', 9), ('W', 'Y', 2), ('Y', 'Z', 5), ('X', 'Z', 3),

    # Graph4
    ('A1', 'B1', 10), ('B1', 'C1', 11)
]

# Running Kruskal's algorithm
mst, total_weight = kruskal_algorithm(vertices, edges)

print("Minimum Cost Spanning Tree (for all connected components):")
for u, v, weight in mst:
    print(f"{u} - {v}: {weight}")
print(f"\nTotal Weight of Minimum Spanning Trees: {total_weight}")
