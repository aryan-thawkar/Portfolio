import heapq

def prim(graph, start_vertex):
    mst = []
    visited = set([start_vertex])
    edges = [
        (cost, start_vertex, to)
        for to, cost in graph[start_vertex].items()
    ]
    heapq.heapify(edges)

    total_cost = 0

    while edges:
        cost, frm, to = heapq.heappop(edges)
        if to not in visited:
            visited.add(to)
            mst.append((frm, to, cost))
            total_cost += cost

            for to_next, cost in graph[to].items():
                if to_next not in visited:
                    heapq.heappush(edges, (cost, to, to_next))

    return mst, total_cost

# Final graph (total MST cost = 15)
graph = {
    'A': {'B': 3, 'D': 2},
    'B': {'A': 3, 'C': 4, 'D': 5, 'E': 7},
    'C': {'B': 4, 'E': 3, 'F': 6},
    'D': {'A': 2, 'B': 5, 'E': 8},
    'E': {'B': 7, 'C': 3, 'D': 8, 'F': 3},
    'F': {'C': 6, 'E': 3}
}

mst, total_cost = prim(graph, 'A')

print("Minimum Spanning Tree:")
for edge in mst:
    print(f"{edge[0]} - {edge[1]} (weight {edge[2]})")

print(f"Total cost of Minimum Spanning Tree: {total_cost}")





