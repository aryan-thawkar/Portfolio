import random
import time
import matplotlib.pyplot as plt

# Greedy Knapsack Function
def greedy_knapsack(n, m, W, P):
    items = [(P[i], W[i], P[i] / W[i]) for i in range(n)]  # (profit, weight, profit/weight)
    items.sort(key=lambda x: x[2], reverse=True)  # Sort by profit-to-weight ratio
    
    total_profit = 0
    for i in range(n):
        if m > 0 and items[i][1] <= m:
            m -= items[i][1]
            total_profit += items[i][0]
        else:
            break
    
    if m > 0 and i < n:
        total_profit += items[i][0] * (m / items[i][1])
    
    return total_profit

# Measure execution time (Run multiple trials)
def measure_time(n, m, trials=5):
    execution_times = []
    for _ in range(trials):
        W = [random.randint(1, 50) for _ in range(n)]  # Random weights
        P = [random.randint(10, 100) for _ in range(n)]  # Random profits
        start_time = time.time()
        result = greedy_knapsack(n, m, W, P)
        end_time = time.time()
        execution_times.append((end_time - start_time) * 1000)  # Convert to ms

    avg_time = sum(execution_times) / trials
    print(f"Execution time for {n} items: {avg_time:.3f} ms")
    return avg_time

# Take input from user
n = int(input("Enter the number of items: "))
m = int(input("Enter the knapsack capacity: "))

# Define test cases without repeating n
num_items = [10, 50, 100, 500, 1000, 5000, min(n, 10000)]
execution_times = [measure_time(size, m) for size in num_items]

# Plot results
plt.plot(num_items, execution_times, marker='o', linestyle='-')
plt.xlabel("Number of Items")
plt.ylabel("Execution Time (ms)")
plt.title("Time Complexity of Greedy Knapsack Algorithm")
plt.grid()
plt.show()