a = 1000
while(a>0):
    a = a * 0.99
    print(a," ")
    