#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    ofstream outFile("random_numbers.txt"); // Open file to write
    if (!outFile) {
        cerr << "Error opening file!" << endl;
        return 1;
    }

    srand(time(0)); // Seed for random number generation
    
    int n;
    cout << "Enter the number of random numbers to generate: ";
    cin >> n;
    
    for (int i = 0; i < n; i++) {
        int randomNumber = rand() % 1000; // Generate a random number between 0 and 999
        outFile << randomNumber << endl;
    }

    outFile.close(); // Close the file
    cout << "Random numbers generated and saved in random_numbers.txt" << endl;

    return 0;
}
