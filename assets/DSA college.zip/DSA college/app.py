import heapq

class Flight:
    def __init__(self, n, i, p, ar, dep, typ):
        self.n = n
        self.i = i
        self.p = p
        self.ar = ar
        self.dep = dep
        self.typ = typ
        self.next = None

class FList:
    def __init__(self):
        self.start = None

    def insert(self, n, i, p, ar, dep, typ):
        x = self.start
        while x != None:
            if x.i == i:
                x.n = n
                x.p = p
                x.ar = ar
                x.dep = dep
                x.typ = typ
                print("Flight", i, "Updated")
                return True
            x = x.next

        newF = Flight(n, i, p, ar, dep, typ)
        newF.next = self.start
        self.start = newF
        print("Flight", i, "Added")
        return True

    def delete(self, i):
        x = self.start
        prev = None
        while x != None:
            if x.i == i:
                if prev == None:
                    self.start = x.next
                else:
                    prev.next = x.next
                print("Flight", i, "Deleted")
                return True
            prev = x
            x = x.next
        print("Flight", i, "Not Found")
        return False

    def size(self):
        c = 0
        temp = self.start
        while temp != None:
            c += 1
            temp = temp.next
        return c

    def isempty(self):
        return self.start == None

    def isfull(self):
        return False

    def findstay(self, f):
        return f.dep - f.ar

    def maxstay(self):
        if self.start == None:
            print("No Flights Found")
            return
        t = self.start
        mx = -1
        res = []
        while t != None:
            staytime = self.findstay(t)
            if staytime > mx:
                mx = staytime
                res = [t]
            elif staytime == mx:
                res.append(t)
            t = t.next

        print("\nFlights with Longest Stay (", mx, "minutes):")
        for k in res:
            self.display(k)

    def sortbykey(self, fun):
        li = []
        t = self.start
        while t != None:
            li.append(t)
            t = t.next

        li.sort(key=fun)

        for i in li:
            self.display(i)

    def sortarr(self):
        print("\nSorted by Arrival Time:")
        self.sortbykey(lambda x: x.ar)

    def sortdep(self):
        print("\nSorted by Departure Time:")
        self.sortbykey(lambda x: x.dep)

    def sortstay(self):
        print("\nSorted by Stay Duration:")
        self.sortbykey(lambda x: x.dep - x.ar)

    def display(self, f):
        print("Name:", f.n, ", ID:", f.i, ", Passengers:", f.p, ", Arrival:", f.ar, ", Departure:", f.dep, ", Type:", f.typ)

    def showall(self):
        if self.start == None:
            print("No flights available")
            return
        temp = self.start
        while temp != None:
            self.display(temp)
            temp = temp.next

def dijkstra(mat, src, dest):
    n = len(mat)
    dist = [9999999] * n
    dist[src] = 0
    vis = [False] * n
    pq = [(0, src)]

    while pq:
        d, u = heapq.heappop(pq)
        if vis[u]:
            continue
        vis[u] = True

        for v in range(n):
            if mat[u][v] > 0 and not vis[v]:
                if dist[v] > d + mat[u][v]:
                    dist[v] = d + mat[u][v]
                    heapq.heappush(pq, (dist[v], v))

    if dist[dest] == 9999999:
        print("No path from", src, "to", dest)
    else:
        print("Shortest Distance from", src, "to", dest, "is", dist[dest])

def start():
    viplist = FList()
    vvlist = FList()
    publist = FList()

    while True:
        print("\n=== Flight Control Menu ===")
        print("1. Add Flight")
        print("2. Delete Flight")
        print("3. Count Flights")
        print("4. Check Empty")
        print("5. Flight with Max Stay")
        print("6. Sort by Arrival Time")
        print("7. Sort by Departure Time")
        print("8. Sort by Stay Time")
        print("9. Find Shortest Path")
        print("10. Show Flights")
        print("11. Quit")

        op = input("Select option: ")

        if op == '1':
            a = input("Enter Name: ")
            b = input("Enter ID: ")
            p = int(input("Passenger Capacity: "))
            ar = int(input("Arrival Time (minutes): "))
            dep = int(input("Departure Time (minutes): "))
            typ = input("Flight Type (VIP/VVIP/PUBLIC): ").upper()

            if typ == "VIP":
                viplist.insert(a, b, p, ar, dep, typ)
            elif typ == "VVIP":
                vvlist.insert(a, b, p, ar, dep, typ)
            elif typ == "PUBLIC":
                publist.insert(a, b, p, ar, dep, typ)
            else:
                print("Wrong Flight Type")

        elif op == '2':
            b = input("Enter Flight ID to remove: ")
            typ = input("Flight Type (VIP/VVIP/PUBLIC): ").upper()
            if typ == "VIP":
                viplist.delete(b)
            elif typ == "VVIP":
                vvlist.delete(b)
            elif typ == "PUBLIC":
                publist.delete(b)
            else:
                print("Wrong Flight Type")

        elif op == '3':
            print("VIP Flights:", viplist.size())
            print("VVIP Flights:", vvlist.size())
            print("Public Flights:", publist.size())

        elif op == '4':
            print("VIP Empty:", viplist.isempty())
            print("VVIP Empty:", vvlist.isempty())
            print("Public Empty:", publist.isempty())

        elif op == '5':
            print("VIP List:")
            viplist.maxstay()
            print("VVIP List:")
            vvlist.maxstay()
            print("Public List:")
            publist.maxstay()

        elif op == '6':
            print("VIP Flights:")
            viplist.sortarr()
            print("VVIP Flights:")
            vvlist.sortarr()
            print("Public Flights:")
            publist.sortarr()

        elif op == '7':
            print("VIP Flights:")
            viplist.sortdep()
            print("VVIP Flights:")
            vvlist.sortdep()
            print("Public Flights:")
            publist.sortdep()

        elif op == '8':
            print("VIP Flights:")
            viplist.sortstay()
            print("VVIP Flights:")
            vvlist.sortstay()
            print("Public Flights:")
            publist.sortstay()

        elif op == '9':
            n = int(input("How many cities: "))
            print("Enter graph matrix row by row:")
            mat = []
            for _ in range(n):
                mat.append(list(map(int, input().split())))
            src = int(input("Source city index: "))
            dest = int(input("Destination city index: "))
            dijkstra(mat, src, dest)

        elif op == '10':
            print("VIP List:")
            viplist.showall()
            print("\nVVIP List:")
            vvlist.showall()
            print("\nPublic List:")
            publist.showall()

        elif op == '11':
            print("Exiting Program")
            break

        else:
            print("Invalid choice. Try again!")

if __name__ == "__main__":
    start()
