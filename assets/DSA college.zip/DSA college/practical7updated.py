import heapq

class Graph:
    def __init__(self, vertices):
        self.vertices = vertices
        self.adj_list = {v: [] for v in vertices}

    def add_edge(self, u, v, weight):
        self.adj_list[u].append((v, weight))
        self.adj_list[v].append((u, weight))  # Comment this line if graph is directed

def dijkstra_algorithm(graph, start_vertex):
    """Function to implement Dijkstra's algorithm to find shortest paths from start_vertex."""
    distances = {v: float('inf') for v in graph.vertices}
    distances[start_vertex] = 0
    priority_queue = [(0, start_vertex)]

    print(f"Initial distances: {distances}")
    print(f"Starting from vertex: {start_vertex}\n")

    while priority_queue:
        current_distance, current_vertex = heapq.heappop(priority_queue)

        print(f"Processing vertex {current_vertex} with current distance {current_distance}")

        for neighbor, weight in graph.adj_list[current_vertex]:
            distance = current_distance + weight
            if distance < distances[neighbor]:
                print(f"  Found shorter path to {neighbor}: old distance = {distances[neighbor]}, new distance = {distance}")
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))

        print(f"Distances after visiting {current_vertex}: {distances}\n")

    return distances

# Define vertices and edges
vertices = ['A', 'B', 'C', 'D', 'E', 'F']
edges = [
    ('A', 'B', 4),
    ('A', 'C', 2),
    ('B', 'C', 1),
    ('B', 'D', 5),
    ('C', 'D', 8),
    ('C', 'E', 10),
    ('D', 'E', 2),
    ('D', 'F', 6),
    ('E', 'F', 3)
]

# Create graph and add edges
graph = Graph(vertices)
for u, v, weight in edges:
    graph.add_edge(u, v, weight)

# Run Dijkstra's algorithm
start_vertex = 'A'
distances = dijkstra_algorithm(graph, start_vertex)

# Final output
print("Final shortest distances from source:")
for vertex in distances:
    print(f"Distance to {vertex}: {distances[vertex]}")
